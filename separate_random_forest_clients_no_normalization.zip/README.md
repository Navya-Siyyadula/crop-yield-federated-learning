# Separate Random Forest Training — 4 Clients

Each client is treated as a separate simulated edge server.

## Important
- NO normalization or scaling is performed.
- Each client's X and y are loaded independently.
- Each client gets its own train/test split.
- Each client gets its own RandomForestRegressor.
- No model parameters or training data are shared between clients.
- Evaluation is performed separately for every client.
- `absolute_error = abs(actual - predicted)` is included for every test sample.
- `MAE_absolute_value` is the mean absolute error over that client's test set.

## Files per client
- `client_N_random_forest.joblib` — trained Random Forest model
- `client_N_predictions.csv` — actual, predicted, and absolute error
- `client_N_metrics.json` — MAE, RMSE, MSE, R2 and dataset details

## Reproduce
Run:
`python train_separate_random_forests.py`

The script expects these files in the same directory:
`client_1_X.csv`, `client_1_y.csv`, ..., `client_4_X.csv`, `client_4_y.csv`.
