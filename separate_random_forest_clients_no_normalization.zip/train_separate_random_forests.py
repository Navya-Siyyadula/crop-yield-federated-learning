import os
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

for cid in [1, 2, 3, 4]:
    X = pd.read_csv(f"client_{cid}_X.csv")
    y = pd.read_csv(f"client_{cid}_y.csv").iloc[:, 0]

    # NO normalization / scaling.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )

    model = RandomForestRegressor(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    abs_error = np.abs(y_test.to_numpy() - pred)

    metrics = {
        "MAE_absolute_value": float(mean_absolute_error(y_test, pred)),
        "MSE": float(mean_squared_error(y_test, pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_test, pred))),
        "R2": float(r2_score(y_test, pred)),
    }

    os.makedirs(f"client_{cid}", exist_ok=True)
    joblib.dump(model, f"client_{cid}/client_{cid}_random_forest.joblib")

    pd.DataFrame({
        "actual": y_test.to_numpy(),
        "predicted": pred,
        "absolute_error": abs_error
    }).to_csv(f"client_{cid}/client_{cid}_predictions.csv", index=False)

    pd.Series(metrics).to_json(f"client_{cid}/client_{cid}_metrics.json", indent=2)
    print(f"Client {cid}: MAE = {metrics['MAE_absolute_value']:.10f}")
